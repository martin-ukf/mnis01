
## Odovzdanie úlohy Git a GitHub
   * Vytvorte Fork z repozitára https://github.com/martin-ukf/mnis01
   * Vyklonujte repozitár na svoj lokálny počítač
   * Pridajte textový súbor do master, v ktorom uvediete všetky príkazy gitu, ktoré ste použili
   * Vytvorte vetvu s názvom MNIS01
   * Do súboru zoznam_prac.xhtml pridajte iniciály vášho mena a názov záverečnej práce, dodržte formát
   * Uskutočnite commit so správou
   * Zlúčte vetvu do master
   * Vytvorte vetvu s názvom MNIS02
   * Doplňte do súboru zoznam_prac.xhtml anotáciu práce
   * Znova uskutočnite commit so správou
   * Zlúčte vetvu do master
   * Naformátujte údaje v súbore zoznam_prac.xhtml pomocou css
   * Nahrajte súbor do vášho repozitára na GitHube
   * Požiadajte o Pull Request súboru zoznam_prac.xhtml
